package com.quiz.web.util;

@SuppressWarnings("serial")
public class WebException extends Exception {

    public WebException(String msg) {
        super(msg);
    }

}
